package Customer;
import java.lang.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.event.*;
import java.awt.*;
public class ShowFrame extends JFrame implements ActionListener, MouseListener
{
    private JPanel p1;
    private JLabel l1, l2, l3, l4, l5, l6, lt1;
    private JButton b1, b2;
    private JTable table;
    private ImageIcon img;
    private Color color1;
    private Font f1, f2, f3;


    
    public ShowFrame()
    {
        super("AVAILABLE");
        super.setBounds(240, 100, 1050, 750);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        p1 = new JPanel();
        p1.setLayout(null);


        f1 = new Font("Arial Black", Font.BOLD,20);
        f2 = new Font("Arial Black", Font.BOLD,40);
        f3 = new Font("Arial Black", Font.BOLD,15);
        f3 = new Font("Arial Black", Font.BOLD,30);


        color1 = new Color(142, 22, 0);

        b2 = new JButton("Back");
        b2.setBounds(450, 650, 150, 30);
        p1.add(b2);
        b2.setBackground(Color.black);
        b2.setForeground(Color.WHITE);
        b2.setOpaque(true);
        b2.addActionListener(this);
        b2.addMouseListener(this);


        String[] columnNames ={"BIKE ID", "Brand","Model","Colour","Hourly Price"};

        Object[][] data = {{"110", "Suzuki", "Gixxer", "Yellow","1000"},
        {"111", "TVS", "Raider", "Black","600"},
        {"112", "TVS", "Apache-4V", "Red","800"},
        {"113", "Suzuki", "GSX-R", "Yellow","2000"},
        {"114", "Bajaj", "Pulsar", "Blue","400"},
        {"115", "Honda", "X-Blade", "Green","850"},
        {"116", "Honda", "Hornet", "Orange","900"},
        {"117", "Bajaj", "Avenger", "Black","1000"},
        {"118", "Hero", "Hunk", "Brown","800"}
    };
        table = new JTable(data, columnNames);
        table.getTableHeader().setBounds(0,0,1050,50);
        table.setBounds(0,50,1050,400);

        this.add(table.getTableHeader());
        this.add(table, BorderLayout.CENTER);

        




        img = new ImageIcon("IMAGES\\White.jpg");
		lt1 = new JLabel(img);
		lt1.setBounds(0,0,1050,750);
		p1.add(lt1);


        super.add(p1);
    }

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == b2)
        {
        b2.setBackground(Color.WHITE);
        b2.setForeground(Color.BLACK);
        }
        else
        {}
    }
    public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == b2)
        {
            b2.setBackground(Color.BLACK);
            b2.setForeground(Color.WHITE);
        }
        else
        {}
    }

    @Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}


    public void actionPerformed(ActionEvent me)
    {
        if(me.getSource() == b2)
        {
            CustomerFrame al1 = new CustomerFrame();
            al1.setVisible(true);
            this.setVisible(false);
        }
    }
}
