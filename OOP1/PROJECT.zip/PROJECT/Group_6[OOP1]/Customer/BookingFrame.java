package Customer;
import Payment.*;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class BookingFrame extends JFrame implements ActionListener, MouseListener
{
    private JPanel p1;
    private JLabel l1, l2, l3, l4, l5, l6, l7, lt1;
    private JButton b1, b2;
    private JTextField tf1, tf2, tf3, tf4, tf5;
    @SuppressWarnings("rawtypes")
    private JComboBox jcb;
    private ImageIcon img;
    private Color color1;
    private Font f1, f2, f3;


    @SuppressWarnings({ "rawtypes", "unchecked" })
    public BookingFrame()
    {
        super("BOOKING PANEL");
        super.setBounds(240, 100, 1050, 750);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
        p1.setLayout(null); 

        f1 = new Font("Arial Black", Font.BOLD,20);
        f2 = new Font("Arial Black", Font.BOLD,40);
        f3 = new Font("Arial Black", Font.BOLD,15);

        color1 = new Color(142, 22, 0);

        l1 = new JLabel("BOOKING PAGE");
        l1.setBounds(310, 40, 400, 50);
        l1.setFont(f2);
        l1.setForeground(Color.WHITE);
        p1.add(l1);


        l2 = new JLabel("Name");
        l2.setBounds(250, 150, 100, 20);
        l2.setFont(f1);
        l2.setForeground(Color.WHITE);
        p1.add(l2);

        l3 = new JLabel("Contact Number");
        l3.setBounds(250, 230, 200, 20);
        l3.setFont(f1);
        l3.setForeground(Color.WHITE);
        p1.add(l3);

        l4 = new JLabel("NID");
        l4.setBounds(250, 310, 100, 20);
        l4.setFont(f1);
        l4.setForeground(Color.WHITE);
        p1.add(l4);

        l5 = new JLabel("Bike ID");
        l5.setBounds(250, 390, 200, 20);
        l5.setFont(f1);
        l5.setForeground(Color.WHITE);
        p1.add(l5);

        l6 = new JLabel("Bike Model");
        l6.setBounds(250, 470, 200, 20);
        l6.setFont(f1);
        l6.setForeground(Color.WHITE);
        p1.add(l6);

        l7 = new JLabel("Travel Time(hours)");
        l7.setBounds(250, 550, 250, 20);
        l7.setFont(f1);
        l7.setForeground(Color.WHITE);
        p1.add(l7);


        tf1 = new JTextField();
        tf1.setBounds(490, 145, 300, 30);
        tf1.setBackground(Color.BLACK);
        tf1.setForeground(Color.WHITE);
        tf1.setFont(f3);
        p1.add(tf1);

        tf2 = new JTextField();
        tf2.setBounds(490, 225, 300, 30);
        tf2.setBackground(Color.BLACK);
        tf2.setForeground(Color.WHITE);
        tf2.setFont(f3);
        p1.add(tf2);

        tf3 = new JTextField();
        tf3.setBounds(490, 305, 300, 30);
        tf3.setBackground(Color.BLACK);
        tf3.setForeground(Color.WHITE);
        tf3.setFont(f3);
        p1.add(tf3);

        tf4 = new JTextField();
        tf4.setBounds(490, 385, 300, 30);
        tf4.setBackground(Color.BLACK);
        tf4.setForeground(Color.WHITE);
        tf4.setFont(f3);
        p1.add(tf4);

        tf5 = new JTextField();
        tf5.setBounds(490, 465, 300, 30);
        tf5.setBackground(Color.BLACK);
        tf5.setForeground(Color.WHITE);
        tf5.setFont(f3);
        p1.add(tf5);



        String arr1[] = new String[] {" ","1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        jcb = new JComboBox(arr1);
        jcb.setBounds(490, 545, 300, 30);
        jcb.setBackground(Color.BLACK);
        jcb.setForeground(Color.WHITE);
        jcb.setFont(f3);
        p1.add(jcb);






        b1 = new JButton("Pay");
        b1.setBounds(450, 600, 150, 30);
        p1.add(b1);
        b1.setBackground(color1);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        b1.addMouseListener(this);

        b2 = new JButton("Back");
        b2.setBounds(450, 650, 150, 30);
        p1.add(b2);
        b2.setBackground(color1);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        b2.addMouseListener(this);


        img = new ImageIcon("IMAGES\\Background.jpg");
		lt1 = new JLabel(img);
		lt1.setBounds(0,0,1050,750);
		p1.add(lt1);


        super.add(p1);

    }


    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(Color.WHITE);
            b1.setForeground(color1);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(Color.WHITE);
            b2.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(color1);
            b1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(color1);
            b2.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}







    public void actionPerformed(ActionEvent me)
    {
        if(me.getSource() == b2)
        {
            CustomerFrame al1 = new CustomerFrame();
            al1.setVisible(true);
            this.setVisible(false);
        }
    
        else if(tf1.getText().isEmpty() == true || tf2.getText().isEmpty() == true || tf3.getText().isEmpty() == true || tf4.getText().isEmpty() == true || tf5.getText().isEmpty() == true)
            {
                JOptionPane.showMessageDialog(null, "Please fill all the information");
            }
        else if(me.getSource() == b1)
            {
                PaymentOption po1 = new PaymentOption();
                po1.setVisible(true);
                this.setVisible(false);
            }
    }
 }



