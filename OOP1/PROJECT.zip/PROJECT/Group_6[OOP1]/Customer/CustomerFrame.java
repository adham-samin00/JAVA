package Customer;
import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class CustomerFrame extends JFrame implements ActionListener, MouseListener
{
    private JPanel p1;
    private JLabel l1, l2, l3, l4, lt1;
    private JButton b1, b2, b3, b4, exit;
    private ImageIcon img;
    private Font f1;
    private Color color1;


   

    public CustomerFrame()
    {
        super("CUSTOMER PANEL");
        super.setBounds(240, 100, 1050, 750);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



         p1 = new JPanel();
         p1.setLayout(null);


         f1 = new Font("Arial Black", Font.BOLD,30);


         color1 = new Color(142, 22, 0);


         exit = new JButton("Exit");
         exit.setBounds(10, 680, 80, 20);
         p1.add(exit);
         exit.setBackground(color1);
         exit.setForeground(Color.WHITE);
         exit.addActionListener(this);


         b1 = new JButton("BOOK A BIKE");
         b1.setBounds(260,100, 500,100);
         p1.add(b1); 
         b1.setBackground(color1);
         b1.setFont(f1);
         b1.setForeground(Color.WHITE);
         b1.addActionListener(this);
         b1.addMouseListener(this);



         b2 = new JButton("RETURN BIKE");
         b2.setBounds(260, 300, 500,100);
         p1.add(b2);
         b2.setBackground(color1);
         b2.setFont(f1);
         b2.setForeground(Color.WHITE);
         b2.addActionListener(this);
         b2.addMouseListener(this);

         b3 = new JButton("AVAILABLE BIKES");
         b3.setBounds(260, 500, 500,100);
         p1.add(b3);
         b3.setBackground(color1);
         b3.setFont(f1);
         b3.setForeground(Color.WHITE);
         b3.addActionListener(this);
         b3.addMouseListener(this);

        img = new ImageIcon("IMAGES\\Background.jpg");
		lt1 = new JLabel(img);
		lt1.setBounds(0,0,1050,750);
		p1.add(lt1);



         super.add(p1);
    }

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(Color.WHITE);
            b1.setForeground(color1);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(Color.WHITE);
            b2.setForeground(color1);
		}
		else if(me.getSource() == b3)
		{
			b3.setBackground(Color.WHITE);
            b3.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(color1);
            b1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(color1);
            b2.setForeground(Color.WHITE);
		}
		else if(me.getSource() == b3)
		{
			b3.setBackground(color1);
            b3.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}







    public void actionPerformed(ActionEvent me)
    {
        if(me.getSource() == b1)
        {
            BookingFrame al1 = new BookingFrame();
            al1.setVisible(true);
            this.setVisible(false);
        }
        else if(me.getSource() == b2)
        {
            ReturnFrame al1 = new ReturnFrame();
            al1.setVisible(true);
            this.setVisible(false);
        }
        else if(me.getSource() == b3)
        {
            ShowFrame al1 = new ShowFrame();
            al1.setVisible(true);
            this.setVisible(false);
        }
        else if(me.getSource() == exit)
        {
            System.exit(0);
        }
    }
}