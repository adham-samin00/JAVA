package Login;

import javax.swing.*;

import ACCOUNT.*;
import Admin.*;
import Customer.*;
import SIGNUP.*;

import java.awt.*;
import java.awt.event.*;
public class LoginFrame extends JFrame implements MouseListener, ActionListener {
    private JPanel panel;
    private JLabel label1, label2, label3, label4, background;
    private JTextField tf;
    private JPasswordField pf;
    private JButton bt, bt2;
    private Font f1, f2, f3;
    private Color color1;
    private ImageIcon background_image;

    public LoginFrame() 
    {
        super("Bike Rental Management!!");
        super.setBounds(240, 100, 1050, 750);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        f1 = new Font("Arial Black", Font.BOLD, 15);
        f2 = new Font("Arial Black", Font.BOLD, 10);
        f3 = new Font("Arial Black", Font.BOLD, 25);

        color1 = new Color(142, 22, 0);

        label4 = new JLabel("Login to Your Account!");
        label4.setBounds(590, 200, 400, 30);
        label4.setForeground(Color.WHITE);
        label4.setFont(f3);
        panel.add(label4);

        label1 = new JLabel("Don't have an Account?");
        label1.setBounds(675, 510, 200, 20);
        label1.setForeground(Color.WHITE);
        label1.setFont(f2);
        panel.add(label1);

        label2 = new JLabel("UserName");
        label2.setBounds(600, 300, 100, 20);
        label2.setForeground(Color.WHITE);
        label2.setFont(f1);
        panel.add(label2);

        tf = new JTextField();
        tf.setBounds(700, 300, 200, 20);
        panel.add(tf);

        label3 = new JLabel("Password");
        label3.setBounds(600, 350, 100, 20);
        label3.setForeground(Color.WHITE);
        label3.setFont(f1);
        panel.add(label3);

        pf = new JPasswordField();
        pf.setBounds(700, 350, 200, 20);
        panel.add(pf);

        bt = new JButton("Login");
        bt.setBounds(700, 400, 80, 20);
        bt.setBackground(Color.WHITE);
        bt.setForeground(color1);
        panel.add(bt);
        bt.addActionListener(this);
        bt.addMouseListener(this);

        bt2 = new JButton("Create new account");
        bt2.setBounds(630, 530, 230, 15);
        bt2.setBackground(Color.WHITE);
        bt2.setForeground(color1);
        panel.add(bt2);
        bt2.addActionListener(this);
        bt2.addMouseListener(this);

        background_image = new ImageIcon("IMAGES\\Login .jpg");
        background = new JLabel("", background_image, JLabel.CENTER);
        background.setBounds(0, 0, 1050, 750);
        panel.add(background);

        super.add(panel);
    }
    
    

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == bt)
        {
            bt.setBackground(color1);
            bt.setForeground(Color.WHITE);
        }
        else if(me.getSource() == bt2)
        {
            bt2.setBackground(color1);
            bt2.setForeground(Color.WHITE);
        }
        
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == bt)
        {
            bt.setBackground(Color.WHITE);
            bt.setForeground(color1);
        }
        else if(me.getSource() == bt2)
        {
            bt2.setBackground(Color.WHITE);
            bt2.setForeground(color1);
        }
    }
    

    public void actionPerformed(ActionEvent me) 
    {
        if (me.getSource() == bt) 
        {

            if(tf.getText().equals("admin") && pf.getText().equals("admin"))
            {
                AdminFrame af1 = new AdminFrame();
                af1.setVisible(true);
                this.setVisible(false);
            }



        String name = tf.getText();
        String pass = new String(pf.getPassword()); 

    
        Account acc = new Account(name, pass);
            if(acc.checkAccount(name, pass) == true) 
            {
                JOptionPane.showMessageDialog(this, "Login Successful");
               
                CustomerFrame obj1 = new CustomerFrame();
                obj1.setVisible(true);
                this.setVisible(false);
            } 
            else if(tf.getText().isEmpty() == true || pf.getText().isEmpty() == true)
            {
                JOptionPane.showMessageDialog(this, "Please fill all the information");
            } 
            else
            {
                JOptionPane.showMessageDialog(this, "Username/Password wrong");
            }
        } 
        else if (me.getSource() == bt2) {
            SignupFrame obj1 = new SignupFrame();
            obj1.setVisible(true);
            this.setVisible(false);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }


}


