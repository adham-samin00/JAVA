package Admin;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class AddFrame  extends JFrame implements ActionListener, MouseListener
{
	private JPanel panel;
	private JLabel l1,l2,l3,l4,l5,l6,l7;
	private JButton bt1,bt2;
	private ImageIcon img;
	private JTextField tf1,tf2,tf3,tf4,tf5;
	private Font f1;
	private Color color1;
	public AddFrame()
	{
		super("Add panel");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(142,22,0);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		l1 = new JLabel("BIKE ID");
		l1.setBounds(270,120,180,40);
		panel.add(l1);
		l1.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l1.setFont(f1);
		
		l2 = new JLabel("BIKE BRAND");
		l2.setBounds(270,220,200,40);
		panel.add(l2);
		l2.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l2.setFont(f1);
		
		l3 = new JLabel("BIKE MODEL");
		l3.setBounds(270,320,180,40);
		panel.add(l3);
		l3.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l3.setFont(f1);
		
		l4 = new JLabel("BIKE COLOR");
		l4.setBounds(270,420,180,40);
		panel.add(l4);
		l4.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l4.setFont(f1);
		
		l5 = new JLabel("HOURLY PRICE");
		l5.setBounds(270,520,200,40);
		panel.add(l5);
		l5.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l5.setFont(f1);
		
		l7 = new JLabel("ADD BIKE");
		l7.setBounds(430,30,200,40);
		panel.add(l7);
		l7.setForeground(color1);
		f1 = new Font("Arial Black",Font.BOLD,30);
		l7.setFont(f1);
		
		
		tf1 = new JTextField();
		tf1.setBounds(490,130,200,30);
		panel.add(tf1);
		tf1.setBackground(Color.BLACK);
		tf1.setForeground(Color.WHITE);
		
		
		tf2 = new JTextField();
		tf2.setBounds(490,230,200,30);
		panel.add(tf2);
		tf2.setBackground(Color.BLACK);
		tf2.setForeground(Color.WHITE);
		
		
		tf3 = new JTextField();
		tf3.setBounds(490,330,200,30);
		panel.add(tf3);
		tf3.setBackground(Color.BLACK);
		tf3.setForeground(Color.WHITE);
		
		
		tf4 = new JTextField();
		tf4.setBounds(490,430,200,30);
		panel.add(tf4);
		tf4.setBackground(Color.BLACK);
		tf4.setForeground(Color.WHITE);
		
		
		tf5 = new JTextField();
		tf5.setBounds(490,530,200,30);
		panel.add(tf5);
		tf5.setBackground(Color.BLACK);
		tf5.setForeground(Color.WHITE);
		
		bt1 = new JButton("ADD");
		bt1.setBounds(480,610,80,30);
		panel.add(bt1);
		bt1.setBackground(color1);
		bt1.setForeground(Color.WHITE);
		bt1.addActionListener(this);
		bt1.addMouseListener(this);
		
		bt2 = new JButton("BACK");
		bt2.setBounds(480,655,80,30);
		panel.add(bt2);
		bt2.setBackground(color1);
		bt2.setForeground(Color.WHITE);
		bt2.addActionListener(this);
		bt2.addMouseListener(this);
		
		img = new ImageIcon("IMAGES\\Background.jpg");
		l6 = new JLabel(img);
		l6.setBounds(0,0,1050,750);
		panel.add(l6);
		
		
		super.add(panel);
	}

	public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(Color.WHITE);
            bt1.setForeground(color1);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(Color.WHITE);
            bt2.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(color1);
            bt1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(color1);
            bt2.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==bt2)
		{
			AdminFrame A1 = new AdminFrame();
			A1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource() == bt1)
		{
			if(tf1.getText().isEmpty() == true || tf2.getText().isEmpty() == true || tf3.getText().isEmpty() == true || tf4.getText().isEmpty() == true || tf5.getText().isEmpty() == true)
			{
				JOptionPane.showMessageDialog(this, "Please fill all the information!");
			}
			else if(tf1.getText().isEmpty() == false && tf2.getText().isEmpty() == false && tf3.getText().isEmpty() == false && tf4.getText().isEmpty() == false && tf5.getText().isEmpty() == false)
			{
				String bId = tf1.getText();
			    String bBrand = tf2.getText();
			    String bModel = tf3.getText();
			    String bColor = tf4.getText();
			    String bHrPrice = tf5.getText();

				Bikes bike = new Bikes(bId, bBrand, bModel, bColor, bHrPrice);
				bike.addBike(bId, bBrand, bModel, bColor, bHrPrice);

			    JOptionPane.showMessageDialog(this, "Bike Added!!");
				AdminFrame ad1 = new AdminFrame();
				ad1.setVisible(true);
				this.setVisible(false);
				
			}

		}
	}
	


}