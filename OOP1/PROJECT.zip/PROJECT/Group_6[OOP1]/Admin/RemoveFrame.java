package Admin;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class RemoveFrame  extends JFrame implements ActionListener, MouseListener
{
	private JPanel panel;
	private JLabel l1,l2,l3,l4,l5;
	private JButton bt1,bt2;
	private JTextField tf1,tf2,tf3;
	private ImageIcon img;
	private Font f1;
	private Color color1;
	public RemoveFrame()
	{
		super("Add panel");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		color1 = new Color(142,22,0);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		l1 = new JLabel("BIKE ID");
		l1.setBounds(300,170,100,50);
		panel.add(l1);
		l1.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l1.setFont(f1);
		
		l2 = new JLabel("BIKE BRAND");
		l2.setBounds(300,270,200,50);
		panel.add(l2);
		l2.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l2.setFont(f1);
		
		l3 = new JLabel("BIKE MODEL");
		l3.setBounds(300,370,200,50);
		panel.add(l3);
		l3.setForeground(Color.WHITE);
		f1 = new Font("Arial BLACK",Font.BOLD,20);
		l3.setFont(f1);
		
		l4 = new JLabel("REMOVE BIKE");
		l4.setBounds(400,30,300,50);
		panel.add(l4);
		l4.setForeground(color1);
		f1 = new Font("Arial Black",Font.BOLD,30);
		l4.setFont(f1);
		
		
		tf1 = new JTextField();
		tf1.setBounds(550,180,300,30);
		panel.add(tf1);
		tf1.setBackground(Color.BLACK);
		tf1.setForeground(Color.WHITE);
		
		tf2 = new JTextField();
		tf2.setBounds(550,280,300,30);
		panel.add(tf2);
		tf2.setBackground(Color.BLACK);
		tf2.setForeground(Color.WHITE);
		
		tf3 = new JTextField();
		tf3.setBounds(550,380,300,30);
		panel.add(tf3);
		tf3.setBackground(Color.BLACK);
		tf3.setForeground(Color.WHITE);
		
		bt1 = new JButton("REMOVE");
		bt1.setBounds(450,530,120,30);
		panel.add(bt1);
		bt1.setBackground(color1);
		bt1.setForeground(Color.WHITE);
		bt1.addActionListener(this);
		bt1.addMouseListener(this);
		
		bt2 = new JButton("BACK");
		bt2.setBounds(450,595,120,30);
		panel.add(bt2);
		bt2.setBackground(color1);
		bt2.setForeground(Color.WHITE);
		bt2.addActionListener(this);
		bt2.addMouseListener(this);
		
		img = new ImageIcon("IMAGES\\Background.jpg");
		l5 = new JLabel(img);
		l5.setBounds(0,0,1050,750);
		panel.add(l5);
		
		
		super.add(panel);
	}

	public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(Color.WHITE);
            bt1.setForeground(color1);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(Color.WHITE);
            bt2.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(color1);
            bt1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(color1);
            bt2.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}




	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==bt2)
		{
			AdminFrame A1 = new AdminFrame();
			A1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource() == bt1)
		{
			if(tf1.getText().isEmpty() == true || tf2.getText().isEmpty() == true || tf3.getText().isEmpty() == true)
			{
				JOptionPane.showMessageDialog(this, "Please fill all the information!");
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Bike Removed!");
				AdminFrame ad1 = new AdminFrame();
				ad1.setVisible(true);
				this.setVisible(false);
			}
		}
	}
}