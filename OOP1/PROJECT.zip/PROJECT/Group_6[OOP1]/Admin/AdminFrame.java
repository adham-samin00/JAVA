package Admin;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminFrame extends JFrame implements  ActionListener, MouseListener
{
	private JPanel panel;
	private JButton bt1,bt2,bt3;
	private Font f1,f2;
	private ImageIcon img;
    private JLabel l1;
	private Color color1;
	
	public AdminFrame()
	{
		super("Admin Panel");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    color1 = new Color(142,22,0);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		bt1= new JButton("ADD BIKE");
		bt1.setBounds(320,220,400,70);
		f1= new Font("arial Black",Font.BOLD,30);
        bt1.setFont(f1);
		bt1.setBackground(color1);
		bt1.setForeground(Color.WHITE);
		bt1.addActionListener(this);
		bt1.addMouseListener(this);
		panel.add(bt1);
		
		bt2= new JButton("REMOVE BIKE");
		bt2.setBounds(320,350,400,70);
		f2= new Font("arial Black",Font.BOLD,30);
        bt2.setFont(f2);
		bt2.setBackground(color1);
		bt2.setForeground(Color.WHITE);
		bt2.addActionListener(this);
		bt2.addMouseListener(this);
		panel.add(bt2);
		
		bt3= new JButton("Exit");
		bt3.setBounds(20,650,100,30);
		bt3.setBackground(color1);
		bt3.setForeground(Color.WHITE);
		bt3.addMouseListener(this);
		panel.add(bt3);
		bt3.addActionListener(this);
		
		img = new ImageIcon("IMAGES\\Background.jpg");
		l1 = new JLabel(img);
		l1.setBounds(0,0,1050,750);
		panel.add(l1);
		
		super.add(panel);
	}	

	public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(Color.WHITE);
            bt1.setForeground(color1);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(Color.WHITE);
            bt2.setForeground(color1);
		}
		else if(me.getSource() == bt3)
		{
			bt3.setBackground(Color.WHITE);
            bt3.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == bt1)
        {
            bt1.setBackground(color1);
            bt1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(color1);
            bt2.setForeground(Color.WHITE);
		}
		else if(me.getSource() == bt3)
		{
			bt3.setBackground(color1);
            bt3.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}





	public void actionPerformed(ActionEvent ae) 
	{
		
		if(ae.getSource() == bt1) 
		{
			AddFrame A1 = new AddFrame();
			A1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()== bt2)
		{
			RemoveFrame A1= new RemoveFrame();
			A1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()== bt3)
		{
			System.exit(0);
		}
	}
}