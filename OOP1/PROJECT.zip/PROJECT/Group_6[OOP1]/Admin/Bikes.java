package Admin;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.*;
import javax.swing.*;
public class Bikes 
{
    private String id;
    private String brand;
    private String model;
    private String color;
    private String hrPrice;

    public Bikes()
    {}
    public Bikes(String id, String brand, String model, String color, String hrPrice)
    {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.color = color;
        this.hrPrice = hrPrice;
    }

    public String getId()
    {
        return this.id;
    }
    public String getBrand()
    {
        return this.brand;
    }
    public String getModel()
    {
        return this.model;
    }
    public String getColor()
    {
        return this.color;
    }
    public String getHrPrice()
    {
        return this.hrPrice;
    }
    public void addBike(String bId, String bBrand, String bModel, String bColor, String bHrPrice)
    {
        try{
            File file = new File("BikeInfo.txt");
            file.createNewFile();
            FileWriter fww = new FileWriter(file, true);
            fww.write("---------------------------------------------------------------");
            fww.write("\n");
            fww.write("Bike id: "+getId()+"\n");
            fww.write("Bike Brand: "+getBrand()+"\n");
            fww.write("Bike Model: "+getModel()+"\n");
            fww.write("Bike Colour: "+getColor()+"\n");
            fww.write("Per Hour Cost: "+getHrPrice()+"\n");
            fww.write("---------------------------------------------------------------");
            fww.flush();
            fww.close();
        }
        catch(IOException i)
        {
            i.printStackTrace();
        }
    }
}
