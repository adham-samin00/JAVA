package SIGNUP;


import java.lang.*;
import javax.swing.*;

import ACCOUNT.*;
import Login.LoginFrame;

import java.awt.event.*;
import java.awt.*;

public class SignupFrame extends JFrame implements ActionListener, MouseListener
{
	private JPanel p1;
    private JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, background2;
    private JTextField tf, tf1, tf2, tf3, tf4, tf5, tf6;
    private ImageIcon background_image2;
    private Color color1;
    private Font f1, f2, f3;
	private JPasswordField pf;
	private JRadioButton rd1, rd2;
	private ButtonGroup bg;
    private JButton bt,bt2;



	
	public SignupFrame()
    {
        super("SIGNUP PANEL");
        super.setBounds(240, 100, 1050, 750);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
        p1.setLayout(null); 

        f1 = new Font("Arial Black", Font.BOLD,15);
        f2 = new Font("Arial Black", Font.BOLD,18);
        f3 = new Font("Arial Black", Font.BOLD,35);


        color1 = new Color(142, 22, 0);
		

		l1 = new JLabel("Sign Up with us");
        l1.setBounds(350, 25, 600, 50);
        l1.setFont(f3);
        l1.setForeground(color1);
        p1.add(l1);
		
		
		
		l2 = new JLabel("Name");
		l2.setBounds(200,100,400,50);
		l2.setForeground(Color.WHITE);
		l2.setFont(f2);
		p1.add(l2);
		

        l3 = new JLabel("Contact Number");
        l3.setBounds(200, 160, 400, 50);
        l3.setFont(f2);
        l3.setForeground(Color.WHITE);
        p1.add(l3);

        l8 = new JLabel("NID");
        l8.setBounds(200, 220, 400, 50);
        l8.setFont(f2);
        l8.setForeground(Color.WHITE);
        p1.add(l8);

        l4 = new JLabel("Email");
        l4.setBounds(200, 280, 400, 50);
        l4.setFont(f2);
        l4.setForeground(Color.WHITE);
        p1.add(l4);

        l5 = new JLabel("Gender");
        l5.setBounds(200, 340, 400, 50);
        l5.setFont(f2);
        l5.setForeground(Color.WHITE);
        p1.add(l5);


        l7 = new JLabel("UserName");
		l7.setBounds(200,400,400,50);
		l7.setForeground(Color.WHITE);
		l7.setFont(f2);
		p1.add(l7);


        l6 = new JLabel("Password");
        l6.setBounds(200, 460, 400, 50);
        l6.setFont(f2);
        l6.setForeground(Color.WHITE);
        p1.add(l6);


        tf = new JTextField();
        tf.setBounds(450, 115, 300, 25);
		tf.setBackground(Color.BLACK);
		tf.setForeground(Color.WHITE);
        p1.add(tf);

        tf1 = new JTextField();
        tf1.setBounds(450, 175, 300, 25);
		tf1.setBackground(Color.BLACK);
		tf1.setForeground(Color.WHITE);
        p1.add(tf1);

        tf2 = new JTextField();
        tf2.setBounds(450, 232, 300, 25);
		tf2.setBackground(Color.BLACK);
		tf2.setForeground(Color.WHITE);
        p1.add(tf2);

        tf3 = new JTextField();
        tf3.setBounds(450, 292, 300, 25);
		tf3.setBackground(Color.BLACK);
		tf3.setForeground(Color.WHITE);
        p1.add(tf3);

        tf4 = new JTextField();
        tf4.setBounds(450, 416, 300, 25);
		tf4.setBackground(Color.BLACK);
		tf4.setForeground(Color.WHITE);
        p1.add(tf4);


		
		rd1 = new JRadioButton("Male");
		rd1.setBounds(450,355,70,20);
		rd1.setBackground(Color.BLACK);
		rd1.setForeground(Color.WHITE);
		p1.add(rd1);
		
		rd2 = new JRadioButton("Female");
		rd2.setBounds(550,355,70,20);
		rd2.setBackground(Color.BLACK);
		rd2.setForeground(Color.WHITE);
		p1.add(rd2);
		
		bg = new ButtonGroup();
		bg.add(rd1);
		bg.add(rd2);

		
		pf = new JPasswordField();
		pf.setBounds(450,475,300,25);
		pf.setBackground(Color.BLACK);
		pf.setForeground(Color.WHITE);
		p1.add(pf);
		
		bt = new JButton("Sign up");
		bt.setBounds(450,580,100,25);
        bt.setBackground(color1);
		bt.setForeground(Color.WHITE);
        p1.add(bt);
		bt.setFont(f1);
		bt.addActionListener(this);
		bt.addMouseListener(this);
		bt.setEnabled(true);



		
		bt2 = new JButton("Back");
		bt2.setBounds(450,630,100,25);
		bt2.setForeground(Color.WHITE);
        bt2.setBackground(color1);
        p1.add(bt2);
		bt2.setFont(f1);
	    bt2.addActionListener(this);
		bt2.addMouseListener(this);
		bt2.setEnabled(true);


		

		
		background_image2 = new ImageIcon("IMAGES\\Background.jpg");
	    background2 = new JLabel("",background_image2,JLabel.CENTER);
        background2.setBounds(0,0,1050,750);
		p1.add(background2);

        
		
		super.add(p1);

	}
	
	public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == bt)
        {
            bt.setBackground(Color.WHITE);
            bt.setForeground(color1);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(Color.WHITE);
            bt2.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == bt)
        {
            bt.setBackground(color1);
            bt.setForeground(Color.WHITE);
        }
		else if(me.getSource() == bt2)
		{
			bt2.setBackground(color1);
            bt2.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

    
	
	public void actionPerformed(ActionEvent me)
	{
		if(me.getSource() == bt2) 
		{
			LoginFrame lf1 = new LoginFrame();
			lf1.setVisible(true);
			setVisible(false);
		}
		else if(me.getSource() == bt) 
		{
			String s1, s2;
					
			s1 = tf4.getText(); 
			s2 = pf.getText(); 
			if (tf.getText().isEmpty() == true || tf1.getText().isEmpty() == true || tf2.getText().isEmpty() == true || tf3.getText().isEmpty() == true || tf4.getText().isEmpty() == true || pf.getText().isEmpty() == true)
			{
				JOptionPane.showMessageDialog(this, "Please fill up all the information");
			}
			else
			{
				Account acc = new Account(s1,s2);
				
				if (acc.checkAccount(s1,s2) == true)
				{
					JOptionPane.showMessageDialog(this,"Username/Password already Exists");
				}
				else 
				{
					acc.addAccount();
					JOptionPane.showMessageDialog(this,"SignUp Successfull");
					tf4.setText("");
					
					pf.setText("");
					
					LoginFrame obj1 = new LoginFrame();
					obj1.setVisible(true);
					this.setVisible(false);
				}
			}
		}
    }
}
    