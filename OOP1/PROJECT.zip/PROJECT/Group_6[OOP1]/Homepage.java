import java.lang.*;
import javax.swing.*;

import Login.*;

import java.awt.*;
import java.awt.event.*;
public class Homepage extends JFrame  implements ActionListener, MouseListener
{
	private JPanel panel;
	private JLabel l1, l2;
	private JButton b1;
	private Color color1;
	private Font f1, f2;
	private ImageIcon img;
	
	
	public Homepage()
	{
		super("Homepage");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



		color1 = new Color(142,22,0);


		f1 = new Font("Arial Black",Font.BOLD,30);
		f2 = new Font("Arial Black",Font.BOLD,40);
		
		panel = new JPanel();
		panel.setLayout(null);



		l2 = new JLabel("VrooM VrooM");
		l2.setBounds(60,600,400,40);
		l2.setFont(f2);
		l2.setForeground(Color.WHITE);
		panel.add(l2);


		b1 = new JButton("Get started");
		b1.setBounds(580,620,250,40);
		panel.add(b1);
		b1.setBackground(color1);
		b1.setForeground(Color.WHITE);
		b1.setFont(f1);
		b1.addActionListener(this);
		b1.addMouseListener(this);
		
		img = new ImageIcon("IMAGES\\Homepage.jpg");
		l1 = new JLabel(img);
		l1.setBounds(0,-22,1050,750);
		panel.add(l1);
		
		
		super.add(panel);
	}

    
    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(Color.WHITE);
            b1.setForeground(color1);
        }
		else
		{}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(color1);
            b1.setForeground(Color.WHITE);
        }
		else
		{

		}	
	}	

	
	@Override
	public void mouseClicked(MouseEvent e) {
	}


	@Override
	public void mousePressed(MouseEvent e) {

	}


	@Override
	public void mouseReleased(MouseEvent e) {
	}


	public void actionPerformed(ActionEvent me)
	{
		if(me.getSource() == b1)
		{
			LoginFrame al1 = new LoginFrame();
			al1.setVisible(true);
			setVisible(false);
		}
	}


}