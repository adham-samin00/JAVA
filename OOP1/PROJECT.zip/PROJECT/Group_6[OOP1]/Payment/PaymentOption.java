package Payment;

import java.lang.*;
import java.lang.*;

import javax.swing.*;

import Customer.BookingFrame;
import Customer.CustomerFrame;

import java.awt.*;
import java.awt.event.*;
public class PaymentOption extends JFrame implements ActionListener, MouseListener
{
	private JPanel panel;
	private JButton b1,b2,b3;
	private JLabel l, l1, l2;
	private Font f1, f2;
	private ImageIcon img;
	private Color color1;
	public PaymentOption()
	{
	    super("Processing panel");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		color1 = new Color(142,22,0);

		f1 = new Font("Arial Black",Font.BOLD,40);
		f2 = new Font("Arial Black",Font.BOLD,20);
		
		panel = new JPanel();
		panel.setLayout(null);

		l = new JLabel("PAYMENT PREFERENCE");
		l.setBounds(250,40,600,35);
		panel.add(l);
		l.setForeground(Color.white);
		l.setFont(f1);

		l2 = new JLabel("*PLEASE PAY YOUR ONE HOUR COST IN ADVANCE");
		l2.setBounds(250,650,600,35);
		panel.add(l2);
		l2.setForeground(Color.RED);
		l2.setFont(f2);


		
		b1 = new JButton("CASH");
		b1.setBounds(380,230,300,60);
		panel.add(b1);
		b1.setForeground(Color.WHITE);
		b1.setFont(f1);
		b1.setForeground(Color.WHITE);
		b1.setBackground(color1);
		b1.setOpaque(true);
		b1.addActionListener(this);
		b1.addMouseListener(this);
		
		
		b2 = new JButton("BKASH");
		b2.setBounds(380,350,300,60);
		panel.add(b2);
		b2.setForeground(Color.WHITE);
		f1 = new Font("Arial Black",Font.BOLD,40);
		b2.setFont(f1);
		b2.setForeground(Color.WHITE);
		b2.setBackground(color1);
		b2.setOpaque(true);
		b2.addActionListener(this);
		b2.addMouseListener(this);
		
		b3 = new JButton("BACK");
		b3.setBounds(380,470,300,60);
		panel.add(b3);
		b3.setForeground(Color.WHITE);
		f1 = new Font("Arial Black",Font.BOLD,40);
		b3.setFont(f1);
		b3.setForeground(Color.WHITE);
		b3.setBackground(color1);
		b3.setOpaque(true);
		b3.addActionListener(this);
		b3.addMouseListener(this);
		
		img = new ImageIcon("IMAGES\\Background.jpg");
		l1 = new JLabel(img);
		l1.setBounds(0,0,1050,750);
		panel.add(l1);
		
		super.add(panel);
		
	}	


	public void mouseEntered(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(Color.WHITE);
            b1.setForeground(color1);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(Color.WHITE);
            b2.setForeground(color1);
		}
		else if(me.getSource() == b3)
		{
			b3.setBackground(Color.WHITE);
            b3.setForeground(color1);
		}
	}
	public void mouseExited(MouseEvent me)
    {
        if(me.getSource() == b1)
        {
            b1.setBackground(color1);
            b1.setForeground(Color.WHITE);
        }
		else if(me.getSource() == b2)
		{
			b2.setBackground(color1);
            b2.setForeground(Color.WHITE);
		}
		else if(me.getSource() == b3)
		{
			b3.setBackground(color1);
            b3.setForeground(Color.WHITE);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}




	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			JOptionPane.showMessageDialog(this, "Please pay your amount at the desk.");
			CustomerFrame bf1 = new CustomerFrame();
			bf1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==b2)
		{
			Payment A1 = new Payment();
			A1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource() == b3)
		{
			BookingFrame al1 = new BookingFrame();
			al1.setVisible(true);
			setVisible(false);
		}
	}
}