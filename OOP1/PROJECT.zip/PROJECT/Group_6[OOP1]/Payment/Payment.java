package Payment;

import java.lang.*;
import javax.swing.*;

import Customer.CustomerFrame;

import java.awt.*;
import java.awt.event.*;
public class Payment extends JFrame implements ActionListener
{
	private JPanel panel;
	private JLabel l1,l2,l3,l4,l5;
	private JTextField tf1,tf2;
	private JButton b1,b2,b3;
	private Font f1,f2, f3;
	private ImageIcon img;
	
	public Payment()
	{
		super("Document panel");
		super.setBounds(240,100,1050,750);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);

		f1 = new Font("Abadi Extra Light",Font.BOLD,30);
		f2 = new Font("Abadi Extra Light",Font.BOLD,15);
		f3 = new Font("Abadi Extra Light",Font.BOLD,20);
		
		l1 = new JLabel("Transaction id");
		l1.setBounds(230,350,300,30);
		panel.add(l1);
		l1.setFont(f1);
		
		l2 = new JLabel("Number");
		l2.setBounds(230,450,300,30);
		panel.add(l2);
		f1 = new Font("Abadi Extra Light",Font.BOLD,30);
		l2.setFont(f1);
		
		l4 = new JLabel("*provide the NUMBER you have paid your bill with.");
		l4.setBounds(350,680,750,30);
		l4.setFont(f2);
		l4.setForeground(Color.RED);
		panel.add(l4);

		l4 = new JLabel("Send Money to 01676011234");
		l4.setBounds(380,300,750,30);
		l4.setFont(f3);
		l4.setForeground(Color.RED);
		panel.add(l4);
		
		
		tf1 = new JTextField();
		tf1.setBounds(550,350,200,30);
		panel.add(tf1);
		
		
		tf2 = new JTextField();
		tf2.setBounds(550,450,200,30);
		panel.add(tf2);
		
		b1 = new JButton("FINISH");
		b1.setBounds(470,550,100,30);
		panel.add(b1);
		b1.setBackground(Color.RED);
		b1.setForeground(Color.WHITE);
		b1.addActionListener(this);
		
		b2 = new JButton("CLOSE");
		b2.setBounds(470,600,100,30);
		panel.add(b2);
		b2.setBackground(Color.RED);
		b2.setForeground(Color.WHITE);
		b2.addActionListener(this);

		b3 = new JButton("Back");
		b3.setBounds(20,20,100,30);
		panel.add(b3);
		b3.setBackground(Color.RED);
		b3.setForeground(Color.WHITE);
		b3.addActionListener(this);
		
		img = new ImageIcon("IMAGES\\Bkash.png");
		l3 = new JLabel(img);
		l3.setBounds(0,0,1050,350);
		panel.add(l3);
		
		
		super.add(panel);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			if(tf1.getText().isEmpty()== true || tf2.getText().isEmpty()== true)
		{
			JOptionPane.showMessageDialog(this, "Please fill all the information");
		}
		else
		{
			JOptionPane.showMessageDialog(this, "VrooM VrooM! YOU ARE GOOD TO GO!!!");
			CustomerFrame cf1 = new CustomerFrame();
			cf1.setVisible(true);
			this.setVisible(false);
		}
		}
		else if(ae.getSource()==b2)
		{
			System.exit(0);
		}
		else if(ae.getSource()==b3)
		{
			PaymentOption po1 = new PaymentOption();
			po1.setVisible(true);
			this.setVisible(false);
		}
	}
}