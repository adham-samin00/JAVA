package  ACCOUNT;

import java.io.*;
import java.util.*;


public class Account 
{

    private String userName;
    private String pass;


    private File file;
    private FileWriter fwrite;
    private Scanner sc;

    public Account() {
    }

    public Account(String userName, String pass) 
    {
        this.userName = userName;
        this.pass = pass;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    public void setPass(String pass)
    {
        this.pass = pass;
    }


    public String getUserName() 
    {
        return this.userName;
    }
    public String getPass() 
    {
        return this.pass;
    }

    public void addAccount() {
        try {
            file = new File("data.txt");
            file.createNewFile();
            if (!file.exists()) {
                file.createNewFile();
            }
            fwrite = new FileWriter(file, true);
            fwrite.write(getUserName() + "\t");
            fwrite.write(getPass() + "\t");
            fwrite.write("\n");

            fwrite.flush();
            fwrite.close();

        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            try {
                if (fwrite != null) {
                    fwrite.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean checkAccount(String userName, String pass) {
        boolean flag = false;
        try {
            file = new File("data.txt");
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] value = line.split("\t");
                if (value[0].equals(userName) && value[1].equals(pass)) 
                {
                    flag = true;
                    //break;
                }
            }
        } catch (IOException io) {
            io.printStackTrace();
        } finally {
            if (sc != null) {
                sc.close();
            }
        }
        return flag;
    }
}