import java.lang.*;
import ACCOUNT.*;
import Admin.*;
import Customer.*;
import Login.*;
import Payment.*;
import SIGNUP.*;
public class Start
{
	public static void main(String [] args)
	{
		Homepage A1 = new Homepage();
		A1.setVisible(true);
	}
}